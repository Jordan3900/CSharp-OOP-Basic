﻿using System;

namespace _01.DefineClassPerson
{
    class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
