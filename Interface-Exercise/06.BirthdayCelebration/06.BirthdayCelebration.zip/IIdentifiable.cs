﻿using System;
using System.Collections.Generic;
using System.Text;


public interface IIdentifiable 
{
    string Id { get; set; }
}

