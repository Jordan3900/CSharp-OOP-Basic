﻿using System;
using System.Collections.Generic;
using System.Text;


public interface ISmartPhone
{
    string Calling(string phone);
    string Browsing(string site);
}

